                             Private Meetings

When a new meeting is created, it can be seen only by its creator (put in his private team).

Copyright November 2013 Olivier Nepomiachty - All rights reserved.

Release notes:
v 1.0.0.0 - 23 Novembre 2013
Original release.
